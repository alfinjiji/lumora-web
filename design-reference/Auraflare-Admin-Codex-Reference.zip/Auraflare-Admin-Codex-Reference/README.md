# Auraflare admin dashboard — Codex design reference

This package contains the latest self-contained dashboard design, including the login page, mobile content-preview fix, team management and profile page. It is a visual and interaction reference, not production application code.

## Open the design

Open index.html in a browser, or serve this folder with `python3 -m http.server 8080` and open http://localhost:8080. The preview needs no build step. Google Fonts need internet access; fallback fonts work offline.

Use any sample email and sample password of at least eight characters to enter the prototype. Do not enter real credentials. The preview does not verify passwords or provide real authentication. No passwords are stored. Sample commerce data and profile changes use browser localStorage. Photo uploads are browser-only, with a 2 MB input limit and a resized avatar.

A hosted private ChatGPT Site may return HTTP 403 to Codex or another browser session. The HTML in this package is sufficient; the hosted URL is not required.

## Included screens and flows

- Login with blank email/password fields, password visibility and sign-out.
- Overview, revenue sample charts, recent orders and stock alerts.
- Orders from website checkout, WhatsApp and Instagram; details, direct-order creation, tracking reference, statuses and CSV export.
- Products: details, collections, scent notes, vessel colours, price, quantity, active/draft state and temporary photo preview.
- Inventory: variants, available stock, low stock below 10 units, out-of-stock state and adjustment reason.
- Enquiries: creation, notes and follow-up status. No messages are sent.
- Website content: responsive hero preview, headline, subtitle, announcement, campaign image preview and featured-collection control.
- Team & access: add user, duplicate email checks, role assignment, edit member and deactivate member.
- My profile: display name, email identifier, phone, bio, avatar upload/removal and password-change form.

## Design direction

Deep wine #42212d, warm background #f7f5f1, near-white cards #fffdfa, text #302b2b, subtle borders #eae5de and restrained antique-gold accents. Cormorant Garamond for headings and DM Sans for interface text. Keep the existing Auraflare public brand consistent. Use readable text, clear focus states, rounded cards and responsive layouts.

## Critical implementation boundaries

- The prototype accepts sample credentials and uses local UI guards. Replace this with real server authentication and authorization. Never port demo authentication to production.
- Implement permissions on every protected endpoint. Hiding controls alone is not access control.
- Users must not select their own role at login. Account roles are assigned by authorized owners. Do not seed a default signed-in user or prefill credentials.
- No production password change currently occurs. The form only checks matching passwords and basic rules. Integrate current-password verification, password hashing and real updates through the existing authentication system.
- Add-user in the prototype creates a local record only. Implement real account provisioning using an expiring invitation/setup token or the repository's established flow. Do not send passwords in email.
- Product photos, banner images, payment updates, shipping, stock movements and storefront publishing need actual services and persistence. UI controls must not claim successful external operations before those operations exist.
- Overview totals and activity are illustrative. Replace them with backend-derived values and a clear reporting period/timezone.
- The featured-collection selector and campaign-image control need real persistence and storefront integration; do not assume every visible control is already connected.
- The preview is not a database schema. Model variants and inventory adjustments explicitly and enforce stock/order rules atomically.

Read CODEX-IMPLEMENTATION-PROMPT.md before changing the application.
