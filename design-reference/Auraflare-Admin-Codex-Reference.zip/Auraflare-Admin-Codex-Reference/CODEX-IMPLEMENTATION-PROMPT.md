Implement the Auraflare admin dashboard in the existing website repository using the attached reference package. Work directly from index.html and README.md; do not fetch the private hosted preview, which can return HTTP 403.

First inspect AGENTS.md, the repository, current application stack, public website branding, authentication, authorization, database models, file storage, tests and existing integrations. Reuse the established architecture and working features. Do not replace the project with a static HTML file or create a second disconnected database. If this is Laravel, use the repository's existing conventions, auth/permission tools, validation, migrations, storage and test framework; otherwise use the equivalent established stack.

Build the visual interface to match the reference: deep wine sidebar, warm ivory background, elegant serif headings, readable sans-serif controls, restrained gold details, rounded cards, responsive tables and accessible forms. Preserve the current public website. Keep admin code/routes appropriately isolated and protected.

Required functionality:
1. Login: empty email and password fields, visibility toggle, accurate validation/errors, session-based sign-in and sign-out, route protection and recovery using the existing auth system. No default user, preset role chooser or unnecessary confirmation screens.
2. Team management: owners can add/invite users with name, email and role, edit permitted details, activate/deactivate users and manage permissions. Enforce unique emails, owner-only access and protection against removing the final active owner. Account provisioning must use a secure setup/invitation flow supported by the repository. Create a reviewable email preview before any real external delivery unless explicitly authorized.
3. My profile: accessible from the avatar and navigation; editable name, phone and bio as appropriate, email change with verification if supported, validated image upload/removal, and a real password-change flow verifying the current password. Store only password hashes. Apply avatar storage validation and authorization server-side. Do not store credentials in localStorage.
4. Orders: website and direct channels, searchable/filterable list, details, create direct orders, payment and fulfilment statuses, tracking, line items and export. Reuse existing payment/shipping services; do not mark payments paid without a valid authorized workflow. Handle stock consistently during order changes.
5. Products and inventory: products, images, descriptions/scent notes, collections, variants, prices, draft/active states, SKU, stock, low-stock alerts and adjustments with reason/history. Use transactional updates where races can affect available stock.
6. Enquiries: contacts, source channel, internal notes, assignment if supported and status. Do not send messages to customers without a requested and supported sending workflow.
7. Website content: hero copy, announcement, featured collection and image assets, preview and real save/publish behavior appropriate to the current website architecture.
8. Overview: metrics computed from real records, defined reporting periods, recent orders and actionable alerts. Use INR and the business timezone Asia/Kolkata where appropriate.

Role baseline: owners manage products, pricing, content, team and all operations. Fulfilment staff can view products, manage orders/shipping, adjust stock, manage enquiries and update their own profile; they cannot edit pricing, publish content or manage accounts. Enforce server-side policies and validate these boundaries with meaningful tests.

Fix the exact mobile defect in the reference history: the content hero preview must grow with text. At 320, 360, 390, 430, 768, 1024 and 1440 px, headings, eyebrow labels, imagery and CTA must remain contained. Avoid fixed-height text frames. Keep forms usable, ensure tables scroll within their cards, avoid page-wide horizontal overflow, make the sidebar accessible and support keyboard navigation and modal focus handling. Check both normal and long copy.

Implementation approach:
- Inspect first, then outline the concrete files and dependencies before editing. Ask only for missing information that blocks implementation; resolve routine choices from the existing repository.
- Work in a feature branch. Implement the complete required flows, adapting models to the current schema. If an integration is unavailable, report the exact blocker and leave accurate UI states rather than simulating success.
- Add appropriate migrations, validation, policies and meaningful tests for authentication, authorization, duplicate users, deactivation, profile/password changes, uploads and stock/order consistency.
- Run required repository checks and responsive browser checks if available. Capture review evidence locally and report any verification limits honestly.
- Do not deploy, send real invitations/messages or run destructive production operations without existing authorization. Provide a reviewable implementation and summarize remaining configuration.
- Finish with changed functionality, validation results, migration/setup steps, remaining blockers and known limitations. Never claim this HTML prototype already provides production security or backend functionality.
