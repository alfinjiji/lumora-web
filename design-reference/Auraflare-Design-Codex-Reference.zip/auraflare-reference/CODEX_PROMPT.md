# Prompt for Codex

Use the attached `auraflare-reference` folder as the authoritative reference for our latest Auraflare candle-store design. Start by reading README.md and all three source files in website/. Inspect the included image assets and run the prototype locally before changing it.

Our approved design is premium dark wine/burgundy with warm ivory and champagne accents. Preserve the current layout, Auraflare branding, supplied candle photographs, rounded image covers, compact sticky navigation, full-background photographic hero, quote-first introduction, subtle scroll and hover effects, responsive layouts and reduced-motion support. Older purple, orange or Stillwick branding is superseded. The Stillwick URL and internal storage key are legacy technical names.

Live reference:
https://stillwick-candle-studio.mailfordev97.chatgpt.site

Use the included source rather than attempting to reconstruct the design from the URL alone. The CSS contains later overrides; use the final computed appearance as the reference. If adapting into an existing codebase, follow that repository's instructions and architecture while preserving the design. Do not create a new repository, change hosting, or deploy unless separately requested.

Keep the current prototype interactions: collection filters and sorting, product detail dialogs, quick-add, bag quantities/removal/subtotal, demo checkout, event enquiry preview, FAQs and intro replay. Preserve keyboard accessibility, visible focus indicators for controls, sticky-header anchor offsets and the fix that prevents a black focus outline around the main page. Use actual included photos; do not substitute invented product imagery or unsupported business claims.

This reference is a frontend prototype. Keep checkout and event enquiries explicitly simulated unless real production implementation is separately requested with confirmed requirements. Do not invent payment credentials, API endpoints, delivery policies, testimonials, product specifications or inventory. Do not silently turn sample prices or catalogue data into production facts.

Validate mobile and desktop in a browser, including navigation, long headings, image cropping, all dialogs, filter/sort results, bag persistence, demo forms, animation completion/skip/Escape/replay and prefers-reduced-motion. Report what changed, what was tested, and any remaining limitations. For visual changes, provide reviewable before/after screenshots if the environment supports them.

Our next requested task:
[Replace this line with the implementation or change we want.]
