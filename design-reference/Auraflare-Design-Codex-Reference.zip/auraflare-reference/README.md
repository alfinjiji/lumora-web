# Auraflare — latest website design reference

Snapshot: 18 October 2026. This package contains the current published prototype, including the navbar outline fix.

Live reference: https://stillwick-candle-studio.mailfordev97.chatgpt.site
Brand: Auraflare. The older Stillwick URL is the existing hosting address, not the brand name.
Source revision: c13891a4c170e88013f5e034c967f083f9e1232c

## What is included

- `website/index.html`: complete page markup, dialogs, brand introduction and metadata.
- `website/style.css`: current desktop/mobile layouts, wine palette, curved frames and motion.
- `website/app.js`: product data, collection filters, cart, simulated checkout, event enquiry preview and animation logic.
- `website/assets/`: nine optimized WebP candle images derived from the supplied photos.
- `CODEX_PROMPT.md`: a ready-to-use handoff prompt.

This is an exact source snapshot, not a screenshot or a video. No hosting credentials, Git history, account data or deployment configuration are included.

## Run locally

No npm install or build is required. From the extracted `auraflare-reference` directory:

```bash
python3 -m http.server 8080 --directory website
```

Open http://localhost:8080. An internet connection loads the optional Google Fonts stylesheet; local font fallbacks remain available. Browser storage holds the shopping bag only.

## Approved visual direction

Premium and elegant candle boutique. Warm candle photography is the focal point. Use restrained motion and generous spacing. The latest approved palette is dark wine/burgundy, warm ivory and muted champagne; earlier purple designs are superseded.

| Role | Current token/value |
| --- | --- |
| Deep wine | `--wine: #38101f` |
| Darkest wine | `--wine-deep: #260b15` |
| Champagne accent | `--champagne: #d6b997` |
| Ivory on dark | `--ivory: #f8eee3` |
| Warm light background | `--cream: #f5eee8` |
| Dark text | `--ink: #30151e` |
| Muted text | `--muted: #7a6268` |
| Wine accent | `--rust: #641d35` |
| Light dividers | `--line: #ddcbd0` |

Use serif display type (Georgia/Times fallback) with selective italic emphasis; use the existing DM Sans/Arial UI stack for controls and body text. Preserve the existing Auraflare wordmark and studio descriptor; the adjacent decorative symbol is part of the prototype, not a supplied final logo.

## Layout and interaction reference

1. Announcement strip scrolls normally. The wine navbar stays at the viewport top. On mobile, the brand/bag row and menu row stay together; there is no line between them.
2. Full-width photographic hero has a wine overlay, curved corners, ivory heading, champagne CTA and slow image motion. Main heading: “A little light. A slower moment.” This is an animated photograph, not a video.
3. Editorial ribbon separates the hero from the collection.
4. Collection: All candles, For your home, For gifting and Sculptural filters; featured and price sorting. Four columns on wide screens, two on smaller screens.
5. Product cards open details; quick-add buttons add to a shopping bag. Bag supports quantity changes, removal and a subtotal.
6. Paired image/text story section, then Home, Gifting and Wedding/event collection cards.
7. Care FAQ, closing CTA and footer. Footer includes a replay-introduction control.
8. Product details, bag, checkout and event enquiry use dialogs.

Image frames are rounded: approximately 20–26px for product cards, 25–30px for editorial cards and 26–32px for the hero, with responsive adjustments. Keep photos clipped to their covers.

## Motion and accessibility

- On each full page load, Auraflare letters animate in, the quote types, then the overlay lifts away. Total duration is about five seconds.
- Skip intro and Escape give immediate access. The footer can replay it.
- Reduced-motion preferences bypass the intro and disable decorative movement.
- Product cards reveal in a staggered sequence as they enter view; new filter/sort results receive the same enhancement.
- Desktop pointer hover uses a small card lift, slow image zoom and subtle button-arrow movement.
- Hero motion is restrained. Avoid aggressive animation or forced scroll.
- Preserve keyboard focus indicators on interactive controls and modal focus behavior. The programmatically focused main landmark must not produce a black frame around the hero.
- Keep anchor offsets large enough for the sticky header, including mobile's two rows.

## Important prototype boundaries

- Product names, prices, copy and variants are illustrative. Do not treat sample products as a validated production catalogue.
- Cart is local to the browser; no backend, accounts, inventory service or actual order records exist.
- Checkout validates demo input and shows a simulated completion. No payment gateway is connected and no delivery information is saved or sent by the prototype.
- Event enquiries are demonstrations only: no email or message is sent and no form details are stored.
- Shipping, returns, tax rules, material/scent/size/burn-time details and final logo require confirmed business inputs before launch.
- Public visibility is enabled on the live reference. This export does not grant access to its hosting account or carry deployment identity.

## Verification status and use

Source syntax, asset paths, palette contrast and selected logic were checked during implementation. The latest layout has not received browser-based visual QA in this environment. Before production, verify desktop and mobile visually and run the complete keyboard, reduced-motion, bag and checkout flow in a browser.

The CSS intentionally includes successive design refinements. Later rules are authoritative. When porting or cleaning it up, preserve computed behavior and appearance rather than selecting an earlier duplicate declaration. The legacy `stillwick-bag` local-storage key is internal and retained to preserve existing bag data; it is not visible branding.
